from base import *

def get_slicetime(input_component, output_component):
    
    json_file = input_component[0].run_bidsname
    
    